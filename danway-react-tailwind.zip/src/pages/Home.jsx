
import React from "react";

const Home = () => {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-b from-white to-blue-50 px-4 text-center">
      <h1 className="text-5xl font-bold text-blue-800 underline mb-4">Welcome to Danway LLC</h1>
      <p className="text-lg text-gray-600 mb-6 max-w-xl">
        Delivering excellence in <strong>MEP, Infrastructure, and Engineering</strong> across the region.
      </p>
      <button className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition">
        Learn More
      </button>
    </div>
  );
};

export default Home;
